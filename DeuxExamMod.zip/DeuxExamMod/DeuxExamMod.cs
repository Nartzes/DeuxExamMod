using Terraria.ModLoader;

namespace DeuxExamMod
{
	public class DeuxExamMod : Mod
	{

	}
}